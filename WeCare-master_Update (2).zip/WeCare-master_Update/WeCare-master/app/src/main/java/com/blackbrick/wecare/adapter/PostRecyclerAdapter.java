package com.blackbrick.wecare.adapter;

import android.content.Context;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.blackbrick.wecare.R;
import com.blackbrick.wecare.activities.SetupActivity;
import com.blackbrick.wecare.classes.post;
import com.blackbrick.wecare.fragments.BloodFragment;
import com.blackbrick.wecare.fragments.BooksFragment;
import com.blackbrick.wecare.fragments.ClothesFragment;
import com.blackbrick.wecare.fragments.FoodFragment;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

// An adapter is the one which helps us to fill data in ui component
// An adapter is the one which will connect our data to our view (in this case recyclerview)
// We are using recycler adapter because we want to display scrolling items

// PostRecyclerAdapter is a custom Adapter
public class PostRecyclerAdapter extends RecyclerView.Adapter<PostRecyclerAdapter.ViewHolder> {

    public List<post> postsList;
    public Context context;
    public String category;

    private Fragment fragment;

    //constructor
    public PostRecyclerAdapter(List<post> postsList,String category,Fragment fragment){
        this.postsList = postsList;
        this.fragment = fragment;
        this.category = category;

    }

    //provide a reference to the views of each item
    public class ViewHolder extends RecyclerView.ViewHolder {
        private View mView;
        private TextView descView, date, post_user_name;
        ImageView delete;
        private ImageView postImage, post_user_image;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;
        }

        public void setDescText(String descText){
            descView = mView.findViewById(R.id.post_desc);
            descView.setText(descText);
        }
        public void setPostImage(Uri postImageUri){
            postImage = mView.findViewById(R.id.post_image);
            Glide.with(context).load(postImageUri).fitCenter().into(postImage);
        }
        public void setDelete(int position){
            delete = mView.findViewById(R.id.delete);
            if(postsList.get(position).getUserId().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())){
               delete.setVisibility(View.VISIBLE);

            }
            else{
                delete.setVisibility(View.GONE);
            }

        }
        public void setDate(Date timestamp){
            date = mView.findViewById(R.id.post_date);
            date.setText(timestamp.toString());
        }
        public void setName(String name){
            post_user_name = mView.findViewById(R.id.post_user_name);
            post_user_name.setText(name);
        }
        public void setUserImage(String postImageUri){
            post_user_image = mView.findViewById(R.id.post_user_image);
            Glide.with(context).load(postImageUri).fitCenter().into(post_user_image);
        }
    }

    // create viewholders for items
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.post_item, parent, false);
        context = parent.getContext();
        return new ViewHolder(view);
    }



    //binds the data to the views
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String desc = postsList.get(position).getDesc();
        String imageUrl = postsList.get(position).getImageUrl();
        Date date = postsList.get(position).getTimeStamp();
        Uri imageUri = Uri.parse(imageUrl);

        holder.setPostImage(imageUri);
        holder.setDescText(desc);
        holder.setDate(date);

        holder.setDelete(position);
        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
                CollectionReference peopleRef = firebaseFirestore.collection("Posts").document(category+" Posts").collection(category);
                 peopleRef.whereEqualTo("userId", postsList.get(holder.getAdapterPosition()).getUserId())
                        .get()
                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                if (task.isSuccessful()) {
                                    for (DocumentSnapshot document : task.getResult()) {
                                        firebaseFirestore.collection("Posts").document(category+" Posts").collection(category).document(document.getId()).delete();
                                        Toast.makeText(context, "Deleted Successfully", Toast.LENGTH_SHORT).show();

                                        if(category.equals("blood")){
                                            ((BloodFragment)fragment).loadData();
                                        }
                                        else if(category.equals("food")){
                                            ((FoodFragment)fragment).loadData();
                                        }
                                        else if(category.equals("clothes")){
                                            ((ClothesFragment)fragment).loadData();
                                        }
                                        else if(category.equals("books")){
                                            ((BooksFragment)fragment).loadData();
                                        }

                                        //notifyItemRemoved(position);
                                        Log.d("TAG", document.getId() + " => " + document.getData());
                                    }
                                } else {
                                    Toast.makeText(context, ""+task.getException(), Toast.LENGTH_SHORT).show();
                                    Log.d("TAG", "Error getting documents: ", task.getException());
                                }
                            }
                        });






            }
        });



        FirebaseFirestore.getInstance().collection("Users").document(postsList.get(position).userId).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful()){
                    if(task.getResult().exists()){
                        String name = task.getResult().getString("name");
                        String image = task.getResult().getString("image");



                        holder.setName(name);
                        holder.setUserImage(image);

                    }
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return postsList.size();
    }


}
