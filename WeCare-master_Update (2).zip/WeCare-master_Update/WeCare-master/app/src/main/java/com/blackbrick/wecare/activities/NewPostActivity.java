package com.blackbrick.wecare.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.blackbrick.wecare.R;
import com.canhub.cropper.CropImage;
import com.canhub.cropper.CropImageView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class NewPostActivity extends AppCompatActivity{
    private int MAX_LENGTH = 100;

    private ImageView newPostImage;
    private EditText newPostDesc;
    private Button newPostBtn;
    private EditText contactnumberID;

    private Uri postImageUri = null;

    private StorageReference storageReference;
    private FirebaseFirestore firebaseFirestore;
    private FirebaseAuth mAuth;

    private String category;

    private Spinner spinner;
    private static final String[] paths = {"Select Category", "Food", "Blood", "Clothes", "Books"};

    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_post);

        progressBar  =findViewById(R.id.progress);
        mAuth = FirebaseAuth.getInstance();
        storageReference = FirebaseStorage.getInstance().getReference();
        firebaseFirestore = FirebaseFirestore.getInstance();

        spinner = findViewById(R.id.spinner);

        newPostImage = findViewById(R.id.postImageID);
        newPostDesc = findViewById(R.id.postdesc_textID);
        newPostBtn = findViewById(R.id.post_btnID);
        contactnumberID = findViewById(R.id.contactnumberID);

        spinner.setPrompt("Select Category");
        ArrayAdapter<String>adapter = new ArrayAdapter<String>(NewPostActivity.this,
                android.R.layout.simple_spinner_item,paths);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                                              @Override
                                              public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                                                  switch (position) {
                                                      case 1:
                                                          //blood fragment
                                                          category = "food";
                                                          break;
                                                      case 2:
                                                          //clothes fragment
                                                          category = "blood";
                                                          break;
                                                      case 3:
                                                          // food fragment
                                                          category = "clothes";
                                                          break;
                                                      case 4:
                                                          // books fragment
                                                          category = "books";
                                                          break;

                                                  }
                                              }

                                              @Override
                                              public void onNothingSelected(AdapterView<?> adapterView) {

                                              }
                                          });

                newPostImage.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent();
                        intent.setType("image/*");
                        intent.setAction(Intent.ACTION_GET_CONTENT);
                        startActivityForResult(Intent.createChooser(intent, "Select Picture"), 10);
//        Intent intent = CropImage
//                .activity()
//                //.setImageSource(includeGallery = false, includeCamera = true)
//                .setGuidelines(CropImageView.Guidelines.ON)
//                .getIntent(this);

                        startActivityForResult(intent, CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE);
//                        CropImage.activity()
//                                .setGuidelines(CropImageView.Guidelines.ON)
//                                .setMinCropResultSize(512, 512)
//                                .setAspectRatio(1, 1)
//                                .start(NewPostActivity.this);
                        /*CropImage.activity()
                                .setGuidelines(CropImageView.Guidelines.ON)
                                .setMinCropResultSize(512, 512)
                                .setAspectRatio(1, 1)
                                .start(NewPostActivity.this);*/
                    }
                });

        newPostBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                final String desc = newPostDesc.getText().toString();
                if(!(contactnumberID.getText().toString().length()==10)) {
                    contactnumberID.setError("Enter 10 digits number");
                }

                else if(!(desc.length() == 0 || postImageUri == null)){
                    String randomName = random();
                    progressBar.setVisibility(View.VISIBLE);
                    StorageReference filePath = storageReference.child("post_images").child(randomName);
                    filePath.putFile(postImageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            final Task<Uri> firebaseUri = taskSnapshot.getStorage().getDownloadUrl();
                            firebaseUri.addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    final String downloadUri = uri.toString();
                                    String user_id = mAuth.getCurrentUser().getUid();

                                    Map<String, Object> postMap = new HashMap<>();
                                    postMap.put("imageUrl", downloadUri);
                                    postMap.put("desc", desc);
                                    postMap.put("userId", user_id);
                                    postMap.put("timeStamp", FieldValue.serverTimestamp());

                                    firebaseFirestore.collection("Posts").document(category + " Posts").collection(category).add(postMap).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                                        @Override
                                        public void onComplete(@NonNull Task<DocumentReference> task) {
                                            if(task.isSuccessful()){
                                                progressBar.setVisibility(View.GONE);
                                                Toast.makeText(NewPostActivity.this, "Post was added", Toast.LENGTH_LONG).show();
                                                addNotification();
                                                Intent intent = new Intent(NewPostActivity.this, MainActivity.class);
                                                startActivity(intent);
                                                finish();
                                            }
                                            else{
                                                progressBar.setVisibility(View.GONE);
                                                String error = task.getException().toString();
                                                Toast.makeText(NewPostActivity.this, error, Toast.LENGTH_LONG).show();
                                            }
                                        }
                                    });
                                }
                            });
                        }
                    });

                }
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 10) {
           // CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                postImageUri = data.getData();
                newPostImage.setImageURI(postImageUri);
            }

//            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
//                Exception error = result.getError();
//            }
        }
    }

    public String random() {
        Random generator = new Random();
        StringBuilder randomStringBuilder = new StringBuilder();
        int randomLength = generator.nextInt(MAX_LENGTH);
        char tempChar;
        for (int i = 0; i < randomLength; i++){
            tempChar = (char) (generator.nextInt(96) + 32);
            randomStringBuilder.append(tempChar);
        }
        return randomStringBuilder.toString();
    }

    private void addNotification() {

        NotificationManager mNotificationManager;

        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(this, "notify_001");
        Intent ii = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, ii, 0);

        NotificationCompat.BigTextStyle bigText = new NotificationCompat.BigTextStyle();
        bigText.bigText("Notification");
        bigText.setBigContentTitle("New Post Added");

        mBuilder.setContentIntent(pendingIntent);
        mBuilder.setSmallIcon(R.mipmap.ic_launcher_round);
        mBuilder.setContentTitle("Your Title");
        mBuilder.setContentText("Your text");
        mBuilder.setPriority(Notification.PRIORITY_MAX);
        mBuilder.setStyle(bigText);

        mNotificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

// === Removed some obsoletes
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            String channelId = "Your_channel_id";
            NotificationChannel channel = new NotificationChannel(
                    channelId,
                    "Channel human readable title",
                    NotificationManager.IMPORTANCE_HIGH);
            mNotificationManager.createNotificationChannel(channel);
            mBuilder.setChannelId(channelId);
        }

        mNotificationManager.notify(0, mBuilder.build());
    }
}


