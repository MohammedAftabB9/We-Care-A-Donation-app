package com.blackbrick.wecare.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.blackbrick.wecare.R;
import com.blackbrick.wecare.activities.MainActivity;
import com.blackbrick.wecare.activities.NewPostActivity;
import com.blackbrick.wecare.adapter.PostRecyclerAdapter;
import com.blackbrick.wecare.classes.post;
import com.bumptech.glide.Glide;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nullable;


/**
 * A simple {@link Fragment} subclass.
**/
public class HomeFragment extends Fragment {


    public HomeFragment() {
        // Required empty public constructor

    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container,false);


        ImageView mainActivityImage = view.findViewById(R.id.main_activity_image);
        ImageView coronaImage = view.findViewById(R.id.corona_image);
        LinearLayout requestLayout = view.findViewById(R.id.requestDonationLayout);
        LinearLayout donationDriveLayout = view.findViewById(R.id.donationDriveLayout);

        Glide.with(getActivity()).load(this.getResources().getDrawable(R.drawable.main_activity_image)).into(mainActivityImage);
        Glide.with(getActivity()).load(this.getResources().getDrawable(R.drawable.main_activity_corona)).into(coronaImage);

        donationDriveLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), NewPostActivity.class);
                startActivity(intent);
            }
        });

        // Inflate the layout for this fragment
        return view;
    }

}
